#!/usr/bin/env python3
"""
RegisV8 - Main Entry Point
HTML Parsing Registration Bot with Modular Architecture
Mode: Multiple accounts per single link
"""

import asyncio
import argparse
import sys
import time
import os
import json
from typing import List

import config as cfg
from models import Account, Site, MissionResult, MissionState, MissionStatus
from loader import load_sites, load_accounts
from http_client import HTTPClient
from parser import extract_shortname, detect_success_from_response
import display as disp
import logger as log


def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="RegisV8 - HTML Parsing Registration Bot (Multi-Account per Link)"
    )
    
    parser.add_argument(
        "--links",
        required=True,
        help="File containing target URLs"
    )
    
    parser.add_argument(
        "--accounts",
        required=True,
        help="File containing account data"
    )
    
    parser.add_argument(
        "--config",
        default="config.json",
        help="Configuration file path (default: config.json)"
    )
    
    parser.add_argument(
        "--concurrency",
        type=int,
        help="Override concurrency setting from config"
    )
    
    parser.add_argument(
        "--output",
        help="Override output folder from config"
    )
    
    parser.add_argument(
        "--mode",
        choices=["account-per-link", "link-per-account"],
        default="account-per-link",
        help="Execution mode: 'account-per-link' (multiple accounts per link) or "
             "'link-per-account' (multiple links per account)"
    )
    
    return parser.parse_args()


def generate_mission_plan_account_per_link(
    sites: List[Site],
    accounts: List[Account]
) -> List[tuple]:
    """
    Generate mission plan: Each link will be tried with ALL accounts
    
    Args:
        sites: List of target sites
        accounts: List of accounts
        
    Returns:
        List of (site, account) tuples for each mission
    """
    missions = []
    
    for site in sites:
        for account in accounts:
            missions.append((site, account))
    
    return missions


def generate_mission_plan_link_per_account(
    sites: List[Site],
    accounts: List[Account]
) -> List[tuple]:
    """
    Generate mission plan: Each account will be tried with ALL links
    
    Args:
        sites: List of target sites
        accounts: List of accounts
        
    Returns:
        List of (site, account) tuples for each mission
    """
    missions = []
    
    for account in accounts:
        for site in sites:
            missions.append((site, account))
    
    return missions


class MultiAccountMissionRunner:
    """
    Extended Mission Runner that supports multiple accounts per link
    With HTML caching for efficiency
    """
    
    def __init__(
        self,
        http_client: HTTPClient,
        state: MissionState,
        logger: log.Logger,
        concurrency: int = 30
    ):
        self.http_client = http_client
        self.state = state
        self.logger = logger
        self.concurrency = concurrency
        self.semaphore = asyncio.Semaphore(concurrency)
        self.site_cache = {}  # Cache HTML parsing results per site
    
    async def run_missions(
        self,
        mission_plan: List[tuple]
    ) -> List[MissionResult]:
        """
        Run registration missions based on mission plan
        
        Args:
            mission_plan: List of (site, account) tuples
            
        Returns:
            List of mission results
        """
        self.state.total_missions = len(mission_plan)
        
        # FIX: Gunakan URL strings untuk menghitung unique sites/accounts
        unique_sites = len(set(site.url for site, _ in mission_plan))
        unique_accounts = len(set(account.username for _, account in mission_plan))
        
        disp.print_section("STARTING MULTI-ACCOUNT DEPLOYMENT")
        disp.print_info(f"Total Missions: {len(mission_plan)}")
        disp.print_info(f"Unique Sites: {unique_sites}")
        disp.print_info(f"Unique Accounts: {unique_accounts}")
        disp.print_info(f"Concurrency: {self.concurrency}")
        
        # Group missions by site URL for better caching
        site_groups = {}
        for idx, (site, account) in enumerate(mission_plan):
            site_url = site.url
            if site_url not in site_groups:
                site_groups[site_url] = []
            site_groups[site_url].append((idx, site, account))
        
        # Display mission plan summary
        disp.print_info("\nMission Plan Summary:")
        for site_url, missions in site_groups.items():
            disp.print_info(f"  {site_url}: {len(missions)} accounts")
        
        # Create tasks for all missions
        tasks = [
            self._execute_mission_with_semaphore(idx, site, account)
            for idx, (site, account) in enumerate(mission_plan)
        ]
        
        # Execute all missions concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        valid_results = []
        for result in results:
            if isinstance(result, Exception):
                disp.print_error(f"Mission failed with exception: {result}")
                self.state.failure_count += 1
            else:
                valid_results.append(result)
        
        return valid_results
    
    async def _execute_mission_with_semaphore(
        self,
        index: int,
        site: Site,
        account: Account
    ) -> MissionResult:
        """Execute mission with semaphore and caching"""
        async with self.semaphore:
            # Update progress periodically
            if (index + 1) % 10 == 0:
                disp.print_progress(
                    self.state.completed_missions,
                    self.state.total_missions,
                    f"Processing {self.state.completed_missions}/{self.state.total_missions}"
                )
                disp.print_stats(
                    self.state.success_count,
                    self.state.completed_missions,
                    self.state.elapsed_time
                )
            
            if (index + 1) % 25 == 0:
                active = self.concurrency - self.semaphore._value
                disp.print_concurrent_status(
                    active,
                    self.state.total_missions,
                    self.concurrency
                )
            
            return await self._execute_single_mission(index + 1, site, account)
    
    async def _execute_single_mission(
        self,
        mission_id: int,
        site: Site,
        account: Account
    ) -> MissionResult:
        """
        Execute single mission with HTML caching per site
        
        Workflow:
        1. GET landing page (or use cache)
        2. Extract shortname from HTML
        3. Build POST URL
        4. POST registration data
        5. Check response
        """
        from urllib.parse import urlparse
        
        start_time = time.time()
        
        result = MissionResult(
            mission_id=mission_id,
            site_url=site.url,
            account=account.username
        )
        
        try:
            # Check cache for this site's HTML and shortname
            cache_key = site.url
            
            if cache_key in self.site_cache:
                # Use cached data
                cached_data = self.site_cache[cache_key]
                final_url = cached_data['final_url']
                short_name = cached_data['short_name']
                
                disp.print_info(
                    f"Mission {mission_id}: Using cached ShortName for {site.url}: {short_name}"
                )
            else:
                # Step 1: GET request to extract shortname from HTML
                disp.print_target(f"GET → {site.url}", mission_id)
                
                get_headers = {
                    "Referer": site.url,
                    "Origin": site.domain
                }
                
                status_get, html_content, resp_headers, final_url = await self.http_client.get(
                    site.url,
                    headers=get_headers
                )
                
                result.http_status_get = status_get
                
                if status_get != 200:
                    disp.print_error(
                        f"Mission {mission_id}: GET request failed with status {status_get}"
                    )
                    result.status = MissionStatus.FAILED
                    result.error_message = f"GET failed: {status_get}"
                    
                    self.state.completed_missions += 1
                    self.state.failure_count += 1
                    
                    return result
                
                # Step 2: Extract shortname from HTML
                short_name = extract_shortname(html_content)
                
                if not short_name:
                    disp.print_error(
                        f"Mission {mission_id}: ShortName not found in HTML"
                    )
                    result.status = MissionStatus.FAILED
                    result.error_message = "ShortName not found in HTML"
                    
                    self.state.completed_missions += 1
                    self.state.failure_count += 1
                    
                    return result
                
                # Cache the result for this site
                self.site_cache[cache_key] = {
                    'final_url': final_url,
                    'short_name': short_name,
                    'html_content': html_content
                }
                
                disp.print_success(
                    f"Mission {mission_id}: ShortName extracted and cached: {short_name}"
                )
            
            result.short_name = short_name
            result.shortname_source = "html_parsing"
            
            # Step 3: Build POST URL
            parsed_final = urlparse(final_url)
            current_base_url = f"{parsed_final.scheme}://{parsed_final.netloc}"
            post_url = f"{current_base_url}/api/AppService/AddUserInfo"
            result.post_url = post_url
            
            # Step 4: Prepare payload with current account
            payload = {
                "Account": account.username,
                "Password": account.password,
                "Email": "",
                "BankType": account.bank_type,
                "BankNum": account.bank_number,
                "BankName": account.bank_name,
                "FullName": account.fullname,
                "userMoneyPwd1": account.password,
                "userMoneyPwd2": account.password,
                "ShortName": short_name
            }
            
            # Log bank type yang digunakan
            result.bank_type_used = account.bank_type
            result.bank_name_used = account.bank_name
            
            disp.print_payload(payload, mission_id)
            
            # Step 5: POST request
            post_headers = {
                "Referer": final_url,
                "Origin": current_base_url,
                "Accept": "application/json, text/plain, */*",
                "Content-Type": "application/json",
                "Language": "id",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty"
            }
            
            disp.print_info(f"Mission {mission_id}: Sending POST request...")
            
            status_post, body, cookies, resp_headers = await self.http_client.post(
                post_url,
                headers=post_headers,
                json_data=payload
            )
            
            result.http_status_post = status_post
            result.response_body = body[:500] if body else ""
            
            # Step 6: Process response
            disp.print_response(status_post, body, mission_id)
            
            if detect_success_from_response(status_post, body):
                result.status = MissionStatus.SUCCESS
                disp.print_mission_result(mission_id, True, short_name)
                
                self.state.success_count += 1
                self.logger.log_success(result)
            else:
                result.status = MissionStatus.FAILED
                result.error_message = f"HTTP {status_post}"
                disp.print_mission_result(mission_id, False)
                
                self.state.failure_count += 1
                self.logger.log_failure(result)
        
        except Exception as e:
            result.status = MissionStatus.FAILED
            result.error_message = str(e)
            
            disp.print_error(f"Mission {mission_id}: Exception: {e}")
            
            self.state.failure_count += 1
            self.logger.log_failure(result)
        
        finally:
            result.execution_time = time.time() - start_time
            self.state.completed_missions += 1
        
        return result


async def main():
    """Main application entry point"""
    
    # Display banner
    disp.print_banner()
    
    try:
        # Parse arguments
        args = parse_arguments()
        
        # Load configuration
        disp.print_section("LOADING CONFIGURATION")
        
        try:
            config = cfg.load_config(args.config)
            disp.print_success(f"Configuration loaded from: {args.config}")
        except FileNotFoundError:
            disp.print_error(f"Configuration file not found: {args.config}")
            disp.print_info("Using default configuration")
            config = cfg.Config()
        
        # Override from command line if provided
        if args.concurrency:
            config.concurrency = args.concurrency
        if args.output:
            config.output_folder = args.output
        
        disp.print_info(f"Mode: {args.mode}")
        disp.print_info(f"Concurrency: {config.concurrency}")
        disp.print_info(f"Timeout: {config.timeout}s")
        disp.print_info(f"Output: {config.output_folder}")
        
        # Load sites
        disp.print_section("LOADING TARGET SITES")
        
        try:
            sites = load_sites(args.links)
            disp.print_success(f"Loaded {len(sites)} target sites")
        except FileNotFoundError:
            disp.print_error(f"Sites file not found: {args.links}")
            return
        except ValueError as e:
            disp.print_error(f"Invalid sites file: {e}")
            return
        
        # Load accounts
        disp.print_section("LOADING ACCOUNTS")
        
        try:
            accounts = load_accounts(args.accounts)
            disp.print_success(f"Loaded {len(accounts)} accounts")
            
            # Display account summary
            disp.print_info("\nAccount Summary:")
            for i, account in enumerate(accounts):
                disp.print_info(
                    f"  {i+1}. {account.username} | {account.fullname} | "
                    f"Bank: {account.bank_name} (Type: {account.bank_type}) | "
                    f"Acc: {account.bank_number}"
                )
        except FileNotFoundError:
            disp.print_error(f"Accounts file not found: {args.accounts}")
            return
        except ValueError as e:
            disp.print_error(f"Invalid accounts file: {e}")
            return
        
        # Generate mission plan
        disp.print_section("GENERATING MISSION PLAN")
        
        if args.mode == "account-per-link":
            mission_plan = generate_mission_plan_account_per_link(sites, accounts)
            disp.print_info(
                f"Mode: Multiple Accounts per Link\n"
                f"  {len(sites)} sites × {len(accounts)} accounts = {len(mission_plan)} missions"
            )
        else:
            mission_plan = generate_mission_plan_link_per_account(sites, accounts)
            disp.print_info(
                f"Mode: Multiple Links per Account\n"
                f"  {len(accounts)} accounts × {len(sites)} sites = {len(mission_plan)} missions"
            )
        
        # Initialize components
        disp.print_section("INITIALIZING COMPONENTS")
        
        state = MissionState()
        logger = log.Logger(config.output_folder)
        
        disp.print_info("Components initialized")
        disp.print_info(f"HTML Cache: Enabled (same site results cached)")
        
        # Create HTTP client and run missions
        async with HTTPClient(
            user_agent=config.user_agent,
            timeout=config.timeout,
            max_redirects=config.max_redirects,
            ssl_verify=config.ssl_verify,
            max_retries=config.retry
        ) as http_client:
            
            # Create multi-account mission runner
            runner = MultiAccountMissionRunner(
                http_client=http_client,
                state=state,
                logger=logger,
                concurrency=config.concurrency
            )
            
            # Run missions
            results = await runner.run_missions(mission_plan)
        
        # Final summary
        disp.print_summary(state)
        
        # Display per-site statistics
        disp.print_section("PER-SITE STATISTICS")
        
        site_stats = {}
        for result in results:
            if result.site_url not in site_stats:
                site_stats[result.site_url] = {
                    'success': 0, 
                    'failed': 0, 
                    'accounts': [],
                    'banks': []
                }
            
            if result.status.value == 'success':
                site_stats[result.site_url]['success'] += 1
                site_stats[result.site_url]['accounts'].append(
                    f"✅ {result.account} ({result.bank_name_used})"
                )
            else:
                site_stats[result.site_url]['failed'] += 1
                site_stats[result.site_url]['accounts'].append(
                    f"❌ {result.account} ({result.bank_name_used}) - {result.error_message}"
                )
        
        for site_url, stats in site_stats.items():
            total = stats['success'] + stats['failed']
            success_rate = (stats['success'] / total * 100) if total > 0 else 0
            disp.print_info(f"\n{site_url}")
            disp.print_info(f"  Success: {stats['success']}/{total} ({success_rate:.1f}%)")
            for acc_status in stats['accounts']:
                disp.print_info(f"    {acc_status}")
        
        # Display per-bank statistics
        disp.print_section("PER-BANK STATISTICS")
        
        bank_stats = {}
        for result in results:
            bank_key = f"{result.bank_name_used} (Type: {result.bank_type_used})"
            if bank_key not in bank_stats:
                bank_stats[bank_key] = {'success': 0, 'failed': 0}
            
            if result.status.value == 'success':
                bank_stats[bank_key]['success'] += 1
            else:
                bank_stats[bank_key]['failed'] += 1
        
        for bank_key, stats in bank_stats.items():
            total = stats['success'] + stats['failed']
            success_rate = (stats['success'] / total * 100) if total > 0 else 0
            disp.print_info(f"  {bank_key}: {stats['success']}/{total} ({success_rate:.1f}%)")
        
        # Save results
        disp.print_section("SAVING RESULTS")
        
        logger.save_results(results)
        disp.print_info(f"Results saved to: {config.output_folder}/result.json")
        
        logger.save_statistics(state, results)
        disp.print_info(f"Statistics saved to: {config.output_folder}/statistics.json")
        
        # Save mission plan for reference
        os.makedirs(config.output_folder, exist_ok=True)
        plan_file = os.path.join(config.output_folder, 'mission_plan.json')
        
        plan_data = {
            'mode': args.mode,
            'total_missions': len(mission_plan),
            'unique_sites': len(set(site.url for site, _ in mission_plan)),
            'unique_accounts': len(set(account.username for _, account in mission_plan)),
            'plan': [
                {
                    'mission_id': idx + 1,
                    'site': site.url,
                    'account': account.username,
                    'bank_type': account.bank_type,
                    'bank_name': account.bank_name
                }
                for idx, (site, account) in enumerate(mission_plan)
            ]
        }
        
        with open(plan_file, 'w', encoding='utf-8') as f:
            json.dump(plan_data, f, indent=2)
        
        disp.print_info(f"Mission plan saved to: {plan_file}")
        
        if state.success_count > 0:
            disp.print_success("🎉 MULTI-ACCOUNT DEPLOYMENT SUCCESSFUL!")
        else:
            disp.print_error("💥 MULTI-ACCOUNT DEPLOYMENT FAILED!")
        
    except KeyboardInterrupt:
        disp.print_warning("\nProcess interrupted by user")
        sys.exit(1)
    except Exception as e:
        disp.print_error(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
