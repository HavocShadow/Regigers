#!/usr/bin/env python3
"""
HTML Parser module for RegisV8
Handles extraction of data from HTML responses
"""

import re
import json
import urllib.parse
from typing import Optional


def extract_shortname(html_content: str) -> Optional[str]:
    """
    Extract systemShortName from HTML content
    
    Methods:
    1. Try to find <script id="appSetting"> and parse JSON
    2. Fallback to regex patterns
    
    Args:
        html_content: Raw HTML content
        
    Returns:
        Extracted shortname or None if not found
    """
    if not html_content:
        return None
    
    try:
        # Method 1: Extract from appSetting script tag
        shortname = _extract_from_appsetting(html_content)
        if shortname:
            return shortname
        
        # Method 2: Extract using regex patterns
        shortname = _extract_by_regex(html_content)
        if shortname:
            return shortname
        
        # Method 3: Search in all script tags
        shortname = _extract_from_all_scripts(html_content)
        if shortname:
            return shortname
        
        return None
        
    except Exception as e:
        print(f"Error extracting shortname: {e}")
        return None


def _extract_from_appsetting(html_content: str) -> Optional[str]:
    """Extract shortname from <script id='appSetting'> tag"""
    script_re = re.compile(
        r'<script[^>]*\bid\s*=\s*["\']appSetting["\'][^>]*>(.*?)</script>',
        re.IGNORECASE | re.DOTALL
    )
    
    match = script_re.search(html_content)
    if not match:
        return None
    
    script_body = match.group(1).strip()
    
    # Decode URL-encoded content
    decoded = urllib.parse.unquote(script_body)
    
    # Try to find JSON object
    json_match = re.search(r'(\{.*\})', decoded, re.DOTALL)
    if json_match:
        json_text = json_match.group(1)
        
        try:
            data = json.loads(json_text)
            if isinstance(data, dict):
                # Search for shortname with case-insensitive keys
                for key in data.keys():
                    if key.lower() == "systemshortname":
                        return data[key]
                
                # Direct access fallback
                for key in ['systemShortName', 'systemshortname', 'shortName', 'shortname']:
                    if key in data:
                        return data[key]
        except json.JSONDecodeError:
            pass
    
    return None


def _extract_by_regex(html_content: str) -> Optional[str]:
    """Extract shortname using regex patterns"""
    patterns = [
        # Main pattern
        r'"systemShortName"\s*:\s*"([^"]+)"',
        # URL encoded pattern
        r'%22systemShortName%22%3A%22([^%]+)%22',
        # Alternative patterns
        r'systemShortName["\']?\s*:\s*["\']([^"\']+)["\']',
        r'shortname["\']?\s*:\s*["\']([^"\']+)["\']',
        r'shortName["\']?\s*:\s*["\']([^"\']+)["\']',
        r'"shortName":"([^"]+)"',
        r"shortName\\\":\\\"([^\\]+)\\\"",
        r'systemShortName\\\":\\\"([^\\]+)\\\"'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, html_content, re.IGNORECASE)
        if match:
            return match.group(1)
    
    return None


def _extract_from_all_scripts(html_content: str) -> Optional[str]:
    """Search for shortname in all script tags"""
    script_pattern = re.compile(
        r'<script[^>]*>(.*?)</script>',
        re.IGNORECASE | re.DOTALL
    )
    
    script_matches = script_pattern.findall(html_content)
    
    for script_content in script_matches:
        match = re.search(
            r'systemShortName\s*[:=]\s*["\']([^"\']+)["\']',
            script_content,
            re.IGNORECASE
        )
        if match:
            return match.group(1)
    
    return None


def detect_success_from_response(status: int, body: str) -> bool:
    """
    Detect if registration was successful based on response
    
    Args:
        status: HTTP status code
        body: Response body
        
    Returns:
        True if registration was successful
    """
    if status != 200:
        return False
    
    if not body:
        return False
    
    try:
        # Try to parse as JSON
        if body.strip().startswith('{'):
            resp_json = json.loads(body)
            code = resp_json.get('code')
            msg = str(resp_json.get('msg', '')).lower()
            
            # Known success patterns
            if code == 9000 and "system error" in msg:
                return True
            if code == 422 and "username sudah ada" in msg:
                return True
            if code in [200, 2000, 0]:
                return True
            if code == 0 and "sukses" in msg:
                return True
    except:
        pass
    
    # Text-based detection
    positive_indicators = [
        "success", "berhasil", "sukses", 
        "registrasi berhasil", "pendaftaran berhasil"
    ]
    
    lower_body = body.lower()
    
    if any(pos in lower_body for pos in positive_indicators):
        return True
    
    # Negative indicators
    negative_indicators = ["error", "gagal", "not found", "unauthorized"]
    
    return not any(neg in lower_body for neg in negative_indicators)

